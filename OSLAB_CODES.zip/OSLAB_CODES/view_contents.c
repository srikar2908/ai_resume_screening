#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *fp;
    char filename[100], line[256];
    int count = 0, choice;

    printf("Enter file name: ");
    scanf("%s", filename);

    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Cannot open file!\n");
        return 1;
    }

    printf("\n1. View file page by page (5 lines at a time)\n");
    printf("2. Show first 10 lines\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    if (choice == 1) {
        // Page by page view
        while (fgets(line, sizeof(line), fp)) {
            printf("%s", line);
            count++;
            if (count % 5 == 0) {  // show 5 lines per page
                printf("\n--Press Enter for next page--");
                getchar(); // consume leftover newline
                getchar(); // wait for user input
            }
        }
    } 
    else if (choice == 2) {
        // Show first 10 lines
        while (fgets(line, sizeof(line), fp) && count < 10) {
            printf("%s", line);
            count++;
        }
    } 
    else {
        printf("Invalid choice.\n");
    }

    fclose(fp);
    return 0;
}

