#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define N 5  // Number of philosophers

sem_t chopstick[N];  // One chopstick per philosopher

void *philosopher(void *num) {
    int id = *(int *)num;

    printf("Philosopher %d is thinking...\n", id);
    sleep(1);
    sem_wait(&chopstick[id]);                 
    sem_wait(&chopstick[(id + 1) % N]);       

    printf("Philosopher %d is eating...\n", id);
    sleep(2);
    sem_post(&chopstick[id]);                 
    sem_post(&chopstick[(id + 1) % N]);       
    printf("Philosopher %d finished eating and left the table.\n", id);

    return NULL;
}

int main() {
    pthread_t thread_id[N];
    int philosophers[N];
    for (int i = 0; i < N; i++) {
        sem_init(&chopstick[i], 0, 1);
    }
    for (int i = 0; i < N; i++) {
        philosophers[i] = i;
        pthread_create(&thread_id[i], NULL, philosopher, &philosophers[i]);
        sleep(1);  // Small delay to reduce deadlock chances
    }
    for (int i = 0; i < N; i++) {
        pthread_join(thread_id[i], NULL);
    }
    for (int i = 0; i < N; i++) {
        sem_destroy(&chopstick[i]);
    }
    printf("\nAll philosophers have finished dining.\n");
    return 0;
}

