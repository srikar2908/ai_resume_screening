#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    pid_t pid;

    printf("Parent process ID: %d\n", getpid());

    pid = fork();  // Create a child process

    if (pid < 0) {
        // Error
        printf("Fork failed!\n");
        return 1;
    } 
    else if (pid == 0) {
        // Child process
        printf("Child process ID: %d\n", getpid());
        printf("Child executing 'ls' command using exec()\n");

        char *args[] = {"ls", NULL};
        execvp(args[0], args);  // Replace child process with 'ls'
        
        // If exec fails
        printf("Exec failed!\n");
    } 
    else {
        // Parent process
        printf("Parent waiting for child to finish...\n");
        wait(NULL);  // Wait for child to complete
        printf("Child finished execution.\n");
    }

    return 0;
}

