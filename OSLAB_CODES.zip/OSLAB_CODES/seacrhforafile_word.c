#include <stdio.h>
#include <string.h>
#include <dirent.h>

int main() {
    char filename[100], word[100], line[200];
    int found = 0;

    printf("Enter filename to search: ");
    scanf("%s", filename);

    // Search file in current directory
    DIR *dir = opendir(".");
    struct dirent *entry;

    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, filename) == 0) {
            printf("File '%s' found!\n", filename);
            found = 1;
            break;
        }
    }
    closedir(dir);

    if (!found) {
        printf("File not found!\n");
        return 0;
    }

    // Search for a word inside the file
    printf("Enter word to search inside file: ");
    scanf("%s", word);

    FILE *fp = fopen(filename, "r");
    int line_num = 1, word_found = 0;

    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, word)) {
            printf("Found '%s' in line %d: %s", word, line_num, line);
            word_found = 1;
        }
        line_num++;
    }

    if (!word_found)
        printf("Word not found in file!\n");

    fclose(fp);
    return 0;
}

