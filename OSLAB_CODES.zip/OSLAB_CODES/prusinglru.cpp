#include <stdio.h>

int main() {
    // Variable Declaration
    int n, f;                   // n: number of pages, f: number of frames
    int pages[50];              // Page reference string
    int frame[10];              // Physical memory frames
    int counter[10];            // Tracks last access time for LRU
    int i, j, k;                // Loop counters
    int pageFaults = 0;         // Total page faults count
    int flag1, flag2;           // Flag1: Page Hit/Fault, Flag2: Empty Frame Check
    int min, pos;               // min: minimum counter value, pos: position of LRU page

    // --- 1. Input ---
    printf("Enter the number of pages: ");
    scanf("%d", &n);
    
    printf("Enter the reference string (page numbers):\n");
    for (i = 0; i < n; i++)
        scanf("%d", &pages[i]);
    
    printf("Enter the number of frames: ");
    scanf("%d", &f);
    
    // Initialize frames and counters
    for (i = 0; i < f; i++) {
        frame[i] = -1;  // -1 indicates an empty frame
        counter[i] = 0; // Initialize last access time
    }
    
    printf("\nPage\tFrames\t\tStatus\n");
    
    // --- 2. LRU Simulation Loop ---
    for (i = 0; i < n; i++) {
        flag1 = flag2 = 0;
        
        // A. Check for Page Hit
        for (j = 0; j < f; j++) {
            if (frame[j] == pages[i]) {
                counter[j] = i + 1; // UPDATE: Mark as Most Recently Used
                flag1 = flag2 = 1;  // Page Hit!
                break;
            }
        }
        
        // B. Handle Page Fault (Empty Frame Available)
        if (flag1 == 0) {
            for (j = 0; j < f; j++) {
                if (frame[j] == -1) {
                    frame[j] = pages[i];
                    counter[j] = i + 1; // Mark as Most Recently Used
                    flag2 = 1;          // Empty frame used
                    break;
                }
            }
        }
        
        // C. Handle Page Fault (Replacement Needed - All Frames Full)
        if (flag2 == 0) {
            // Find Least Recently Used (LRU) page
            min = counter[0];
            pos = 0;
            for (j = 1; j < f; j++) {
                if (counter[j] < min) { // The lowest counter value is the LRU
                    min = counter[j];
                    pos = j;
                }
            }
            
            // Replace LRU page at position 'pos'
            frame[pos] = pages[i];
            counter[pos] = i + 1; // New page is now MRU
        }
        
        // --- 3. Output Current State ---
        printf("%d\t", pages[i]);
        for (j = 0; j < f; j++) {
            if (frame[j] != -1)
                printf("%d ", frame[j]);
            else
                printf("- ");
        }
        
        if (flag1 == 0)
            printf("\tPage Fault\n");
        else
            printf("\tNo Fault\n");
            
        if (flag1 == 0)
            pageFaults++;
    }
    
    // --- 4. Final Result ---
    printf("\nTotal Page Faults = %d\n", pageFaults);
    return 0;
}
