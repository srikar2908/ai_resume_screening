#include<stdio.h>
#include<unistd.h>
#include<pthread.h>
#define maxports 2
#define totalprocess 5
int availports=maxports;
pthread_mutex_t lock;
pthread_cond_t cond;
void* openport(void *pid)
{
	int id=*(int*)pid;
	pthread_mutex_lock(&lock);
	while(availports==0)
	{
		printf("process %d waiting for a port\n",id);
		pthread_cond_wait(&cond,&lock);
	}
	availports-=1;
	printf("process %d opened a port,remaining ports are %d\n",id,availports);
	pthread_mutex_unlock(&lock);
	sleep(2);
	pthread_mutex_lock(&lock);
	availports+=1;
	printf("process %d closed port, remaining ports are %d\n",id,availports);
	pthread_cond_signal(&cond);
	pthread_mutex_unlock(&lock);
	return NULL;
}
int main()
{
	int ids[totalprocess];
	int i;
	pthread_t threads[totalprocess];
	pthread_mutex_init(&lock,NULL);
	pthread_cond_init(&cond,NULL);
	for(i=0;i<totalprocess;i++)
	{
		ids[i]=i+1;
		pthread_create(&threads[i],NULL,&openport,&ids[i]);
		sleep(1);
		
	}
	for(i=0;i<totalprocess;i++)
	{
		pthread_join(threads[i],NULL);
	}
	pthread_mutex_destroy(&lock);
	pthread_cond_destroy(&cond);
	return 0;
}
