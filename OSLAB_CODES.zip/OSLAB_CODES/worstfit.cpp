#include <stdio.h>

int main() {
    // Variable Declaration
    int nb, np;                 // nb: number of blocks, np: number of processes
    int b[10];                  // Array for memory block sizes
    int p[10];                  // Array for process sizes
    int allocation[10];         // Stores allocated block index for each process
    int i, j;                   // Loop counters
    int worst;                  // Stores the index of the worst (largest suitable) block

    // --- 1. Input: Memory Blocks ---
    printf("Enter the number of memory blocks: ");
    scanf("%d", &nb);

    printf("Enter the size of each block:\n");
    for (i = 0; i < nb; i++) {
        printf("Block %d: ", i + 1);
        scanf("%d", &b[i]);
    }

    // --- 2. Input: Processes ---
    printf("Enter the number of processes: ");
    scanf("%d", &np);

    printf("Enter the size of each process:\n");
    for (i = 0; i < np; i++) {
        printf("Process %d: ", i + 1);
        scanf("%d", &p[i]);
    }

    // Initialize allocation array (-1 means not allocated)
    for (i = 0; i < np; i++)
        allocation[i] = -1;

    // --- 3. Worst Fit Allocation Logic ---
    for (i = 0; i < np; i++) { // Iterate through all processes
        worst = -1;            // Reset 'worst' block index for the new process

        for (j = 0; j < nb; j++) { // Search for the largest suitable block
            // 1. Check if the block can fit the process
            if (b[j] >= p[i]) {
                // 2. Check if this is the first suitable block found (worst == -1)
                //    OR if this block is larger than the current 'worst' block (b[j] > b[worst])
                if (worst == -1 || b[j] > b[worst])
                    worst = j; // Update 'worst' to the index of the current largest block
            }
        }

        if (worst != -1) { // If a suitable block was found
            allocation[i] = worst;
            b[worst] -= p[i]; // Reduce the block size by the process size
        }
    }

    // --- 4. Display Allocation Results ---
    printf("\n--- Worst Fit Allocation Results ---\n");
    printf("Process No.\tProcess Size\tBlock No.\n");
    
    for (i = 0; i < np; i++) {
        if (allocation[i] != -1)
            // Block index is 'allocation[i]', so block number is 'allocation[i] + 1'
            printf("%d\t\t%d\t\t%d\n", i + 1, p[i], allocation[i] + 1);
        else
            printf("%d\t\t%d\t\tNot Allocated\n", i + 1, p[i]);
    }

    return 0;
}
