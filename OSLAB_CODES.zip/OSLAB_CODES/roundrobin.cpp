#include <stdio.h>

int main() {
    int n, i, tq, time = 0;
    int bt[20], rem[20], wt[20], tat[20];
    float avgwt = 0, avgtat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    printf("Enter burst times:\n");
    for (i = 0; i < n; i++) {
        printf("P%d: ", i + 1);
        scanf("%d", &bt[i]);
        rem[i] = bt[i];
    }

    printf("Enter Time Quantum: ");
    scanf("%d", &tq);

    printf("\nGantt Chart:\n|");
    
    int gantt[200];   // store time points
    int gp = 0;
    gantt[gp++] = 0;

    while (1) {
        int done = 1;

        for (i = 0; i < n; i++) {
            if (rem[i] > 0) {
                done = 0;

                printf(" P%d |", i + 1);

                if (rem[i] > tq) {
                    time += tq;
                    rem[i] -= tq;
                } else {
                    time += rem[i];
                    wt[i] = time - bt[i];
                    rem[i] = 0;
                }

                gantt[gp++] = time;
            }
        }

        if (done)
            break;
    }

    // Turnaround time
    for (i = 0; i < n; i++) {
        tat[i] = bt[i] + wt[i];
        avgwt += wt[i];
        avgtat += tat[i];
    }

    avgwt /= n;
    avgtat /= n;

    // Print timeline
    printf("\n");
    for (i = 0; i < gp; i++) {
        printf("%d ", gantt[i]);
    }

    // Final table
    printf("\n\nProcess\tBurst\tWaiting\tTurnaround\n");
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\n", i + 1, bt[i], wt[i], tat[i]);
    }

    printf("\nAverage Waiting Time: %.2f", avgwt);
    printf("\nAverage Turnaround Time: %.2f\n", avgtat);

    return 0;
}

