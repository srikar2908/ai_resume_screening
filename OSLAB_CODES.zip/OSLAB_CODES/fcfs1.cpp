#include <stdio.h>

int main() {
    int n, i;
    int bt[20], wt[20], tat[20];
    float avgwt = 0, avgtat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    printf("Enter burst time for each process:\n");
    for (i = 0; i < n; i++) {
        printf("P%d: ", i + 1);
        scanf("%d", &bt[i]);
    }

    wt[0] = 0;  // Waiting time for first process is 0

    // Calculate waiting time
    for (i = 1; i < n; i++) {
        wt[i] = 0;
        for (int j = 0; j < i; j++)
            wt[i] += bt[j];
        avgwt += wt[i];
    }

    // Calculate turnaround time
    printf("\nGantt Chart:\n|");
    for (i = 0; i < n; i++) {
        printf(" P%d |", i + 1);
        tat[i] = bt[i] + wt[i];
        avgtat += tat[i];
    }

    // Print Gantt Chart timing
    printf("\n0");
    int total = 0;
    for (i = 0; i < n; i++) {
        total += bt[i];
        printf(" %d", total);
    }

    avgwt /= n;
    avgtat /= n;

    // Display results
    printf("\n\nProcess\tBurst\tWaiting\tTurnaround\n");
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\n", i + 1, bt[i], wt[i], tat[i]);
    }

    printf("\nAverage Waiting Time: %.2f", avgwt);
    printf("\nAverage Turnaround Time: %.2f\n", avgtat);

    return 0;
}

