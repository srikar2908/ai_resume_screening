#include <stdio.h>

int main() {
    char src[50], dest[50];
    FILE *f1, *f2;
    char ch;

    printf("Enter source file: ");
    scanf("%s", src);
    printf("Enter destination file: ");
    scanf("%s", dest);

    f1 = fopen(src, "r");
    f2 = fopen(dest, "w");

    if (!f1 || !f2) {
        printf("File error!\n");
        return 1;
    }

    while ((ch = fgetc(f1)) != EOF) {
        fputc(ch, f2);
    }

    printf("File copied successfully.\n");

    fclose(f1);
    fclose(f2);
    return 0;
}

