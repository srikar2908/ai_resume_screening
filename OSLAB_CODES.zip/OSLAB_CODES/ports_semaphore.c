#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define MAX_PORTS 3
#define TOTAL_PROCESSES 8

sem_t portSemaphore;

void* open_port(void* process_id) {
    int id = *(int*)process_id;
    printf("Process %d is waiting to open a port...\n", id);

    sem_wait(&portSemaphore);

    printf("Process %d has opened a port.\n", id);
    sleep(2);

    printf("Process %d is closing the port.\n", id);
    sem_post(&portSemaphore);

    return NULL;
}

int main() {
    pthread_t threads[TOTAL_PROCESSES];
    int process_ids[TOTAL_PROCESSES];
    int i;
    sem_init(&portSemaphore, 0, MAX_PORTS);

    for (i = 0; i < TOTAL_PROCESSES; i++) {
        process_ids[i] = i + 1;
        pthread_create(&threads[i], NULL, open_port, &process_ids[i]);
        sleep(1);
    }

    for (i = 0; i < TOTAL_PROCESSES; i++) {
        pthread_join(threads[i], NULL);
    }

    sem_destroy(&portSemaphore);

    printf("\nAll processes have completed.\n");

    return 0;
}

