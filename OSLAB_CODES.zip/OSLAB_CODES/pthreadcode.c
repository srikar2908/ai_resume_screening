#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
void* task1(void *arg)
{
	int i;
	for(i=1;i<6;i++){
	
	printf("\nthread 1:counting %d",i);
	sleep(1);}
	pthread_exit(NULL);
}

void* task2(void* arg)
{
	int i;
	for(i=1;i<6;i++){
	
	printf("\nthread 2:counting %d",i);
	sleep(1);}
	pthread_exit(NULL);
}
int main()
{
	pthread_t t1,t2;
	printf("creating threaads...");
	pthread_create(&t1,NULL,task1,NULL);
	pthread_create(&t2,NULL,task2,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("\nboth threads executed sucessfully");
	return 0;
}
