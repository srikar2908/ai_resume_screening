#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    // Show current user
    char *user = getenv("USERNAME"); // for Windows
    if (user == NULL)
        user = getenv("USER"); // for Linux
    printf("Current User: %s\n", user);

    // Show current date and time
    time_t now;
    time(&now);
    printf("Current Date and Time: %s", ctime(&now));

    return 0;
}

