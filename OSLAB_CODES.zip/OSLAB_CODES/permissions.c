#include <stdio.h>
#include <sys/stat.h>

int main() {
    struct stat fileStat;
    char filename[100];

    printf("Enter file name: ");
    scanf("%s", filename);

    if (stat(filename, &fileStat) < 0) {
        printf("Error getting file info!\n");
        return 1;
    }

    printf("File Size: %ld bytes\n", fileStat.st_size);
    printf("Owner Permissions: ");
    printf((fileStat.st_mode & S_IRUSR) ? "r" : "-");
    printf((fileStat.st_mode & S_IWUSR) ? "w" : "-");
    printf((fileStat.st_mode & S_IXUSR) ? "x\n" : "-\n");

    return 0;
}

