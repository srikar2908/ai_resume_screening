#include <stdio.h>

int main() {
    // Memory Structure Variables
    int memsize;           // Total logical memory size (in bytes)
    int pagesize;          // Size of each page/frame (in bytes)
    int no_of_pages;       // Calculated number of pages
    int no_of_frames;      // Calculated number of frames (assumed equal to pages)

    // Page Table and Loop Variables
    int frameno[20];       // Array storing Frame No. for each Page No. (the Page Table)
    int page_table[20];    // (Unused in the original code, but kept for exactness)
    int i;                 // Loop counter

    // Address Translation Variables
    int logical_addr;      // Input logical address
    int page_no;           // Calculated page number (P)
    int offset;            // Calculated offset (D)
    int physical_addr;     // Resulting physical address

    // --- 1. Memory Setup Input ---
    printf("Enter the memory size (in bytes): ");
    scanf("%d", &memsize);

    printf("Enter the page size (in bytes): ");
    scanf("%d", &pagesize);

    // Calculate structure parameters
    no_of_pages  = memsize / pagesize;
    no_of_frames = no_of_pages; // assume equal no. of frames

    printf("\nNumber of Pages:  %d", no_of_pages);
    printf("\nNumber of Frames: %d\n", no_of_frames);

    // --- 2. Build Page Table ---
    printf("\nEnter the Frame number where each page is stored:\n");
    for (i = 0; i < no_of_pages; i++) {
        printf("Page %d : ", i);
        scanf("%d", &frameno[i]);
    }

    // Display Page Table
    printf("\nPage Table:\n");
    printf("Page No.\tFrame No.\n");
    for (i = 0; i < no_of_pages; i++)
        printf("%d\t\t%d\n", i, frameno[i]);

    // --- 3. Address Translation ---
    printf("\nEnter a Logical Address (in decimal): ");
    scanf("%d", &logical_addr);

    // Calculate P and D
    page_no = logical_addr / pagesize;
    offset  = logical_addr % pagesize;

    // Validation (Page Boundary Check and Page Fault Check)
    if (page_no >= no_of_pages || frameno[page_no] == -1) {
        printf("Invalid logical address or page not present in memory!\n");
    } else {
        // Calculation: Physical Address = (Frame No. * Page Size) + Offset
        physical_addr = (frameno[page_no] * pagesize) + offset;

        // Display results
        printf("\n--- Address Translation ---\n");
        printf("Page Number      : %d\n", page_no);
        printf("Offset           : %d\n", offset);
        printf("Frame Number     : %d\n", frameno[page_no]);
        printf("Physical Address : %d\n", physical_addr);
    }

    return 0;
}
