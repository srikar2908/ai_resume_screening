#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    char name[100];

    printf("Enter file or directory name to delete: ");
    scanf("%s", name);

    // Try removing the file or directory
    if (remove(name) == 0)
        printf("Deleted successfully: %s\n", name);
    else
        perror("Error deleting");

    return 0;
}

