#include<stdio.h>
#include<unistd.h>
int main()
{
	int pid=fork();
	if(pid<0)
	printf("fork failed");
	else if(pid==0)
	{
		printf("child process created pid:%d",getpid());
	}
	else
	{
		printf("parent processes pid:%d and child process pid:%d ",getpid(),pid);
	}
	return 0;
}
