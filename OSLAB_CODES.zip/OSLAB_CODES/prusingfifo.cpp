#include <stdio.h>

int main() {
    int i, j, n, f;
    int page[50];         // Array to store the page reference string
    int frame[10];        // Array to represent the physical memory frames
    int count = 0;        // Used as the 'pointer' to track the frame to be replaced next (FIFO logic)
    int pageFaults = 0;   // Counter for the total number of page faults

    // --- 1. Input ---
    printf("Enter the number of pages: ");
    scanf("%d", &n);

    printf("Enter the reference string (page numbers):\n");
    for (i = 0; i < n; i++) {
        scanf("%d", &page[i]);
    }

    printf("Enter the number of frames: ");
    scanf("%d", &f);

    // Initialize frames to -1 (empty state)
    for (i = 0; i < f; i++)
        frame[i] = -1;

    printf("\nPage\tFrames\t\tStatus\n");

    // --- 2. FIFO Simulation ---
    for (i = 0; i < n; i++) {
        int flag = 0; // flag = 0 means Page Fault (page not found)

        // Check if the current page is already in a frame (Hit)
        for (j = 0; j < f; j++) {
            if (frame[j] == page[i]) {
                flag = 1; // Page hit!
                break;
            }
        }

        // If page not found (flag == 0) -> Page Fault occurs
        if (flag == 0) {
            // Replace the page at the 'count' index (FIFO replacement)
            frame[count] = page[i];

            // Move the count pointer to the next frame in a circular fashion (0, 1, 2, ..., f-1, 0, ...)
            count = (count + 1) % f;

            pageFaults++;
        }

        // --- 3. Output Current State ---
        printf("%d\t", page[i]);
        for (j = 0; j < f; j++) {
            if (frame[j] != -1)
                printf("%d ", frame[j]);
            else
                printf("- "); // Print '-' for an empty frame
        }

        if (flag == 0)
            printf("\tPage Fault\n");
        else
            printf("\tNo Fault\n");
    }

    // --- 4. Final Result ---
    printf("\nTotal Page Faults = %d\n", pageFaults);
    
    return 0;
}
