#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    pid_t pid = fork();  // Create a child process

    if (pid < 0) {       // fork failed
        printf("Fork failed!\n");
        return 1;
    }

    if (pid == 0) {      // Child process
        printf("Child process: PID = %d\n", getpid());
        printf("Child exiting...\n");
        exit(0);         // Child exits
    } else {             // Parent process
        wait(NULL);      // Wait for child to finish
        printf("Parent process: PID = %d\n", getpid());
        printf("Child has finished. Parent exiting...\n");
    }

    return 0;
}

