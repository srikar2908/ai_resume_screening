#include<stdio.h>
void findwaitingtime(int n,int bt[],int wt[])
{
	wt[0]=0;
	for(int i=1;i<n;i++)
	wt[i]=bt[i-1]+wt[i-1];
}
void findtat(int n,int bt[],int wt[],int tat[])
{
	for(int i=0;i<n;i++)
	tat[i]=bt[i]+wt[i];
}
void findavgtime(int processes[],int n,int bt[])
{
	int totalwt=0;
	int totaltat=0;
	int wt[n],tat[n];
	findwaitingtime(n,bt,wt);
	findtat(n,bt,wt,tat);
	for (int i=0;i<n;i++)
	{
		totalwt+=wt[i];
		totaltat+=tat[i];
		printf("%d",n);
		printf("\t%d",bt[i]);
		printf("\t%d",wt[i]);
		printf("\t%d",tat[i]);
		printf("\n");
	}
	printf("\ntotal avg waiting time:%f",float(totalwt/float(n)));
	printf("\ntotal avg tat:%f",float(totaltat/float(n)));
}
int main()
{
	int processes[]={1,2,3};
	int n=sizeof processes/sizeof processes[0];
	int bt[]={10,5,8};
	findavgtime(processes,n,bt);
	return 0;
	
}
