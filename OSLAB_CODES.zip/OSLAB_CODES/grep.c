#include <stdio.h>
#include <string.h>

int main() {
    char word[50], filename[50], line[200];
    FILE *f;

    printf("Enter word to search: ");
    scanf("%s", word);
    printf("Enter filename: ");
    scanf("%s", filename);

    f = fopen(filename, "r");
    if (!f) {
        printf("File not found!\n");
        return 1;
    }

    while (fgets(line, sizeof(line), f)) {
        if (strstr(line, word)) {
            printf("%s", line);
        }
    }

    fclose(f);
    return 0;
}

