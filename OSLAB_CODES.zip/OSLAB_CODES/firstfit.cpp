#include <stdio.h>

int main() {
    // Variable Declaration
    int nb, np;                 // nb: number of blocks, np: number of processes
    int b[10];                  // Array to store memory block sizes
    int p[10];                  // Array to store process sizes
    int allocation[10];         // Stores the allocated block index for each process (-1 if unallocated)
    int i, j;                   // Loop counters

    // --- 1. Input: Memory Blocks ---
    printf("Enter the number of memory blocks: ");
    scanf("%d", &nb);

    printf("Enter the size of each block:\n");
    for (i = 0; i < nb; i++) {
        printf("Block %d: ", i + 1);
        scanf("%d", &b[i]);
    }

    // --- 2. Input: Processes ---
    printf("Enter the number of processes: ");
    scanf("%d", &np);

    printf("Enter the size of each process:\n");
    for (i = 0; i < np; i++) {
        printf("Process %d: ", i + 1);
        scanf("%d", &p[i]);
    }

    // Initialize allocation array (-1 means not allocated)
    for (i = 0; i < np; i++)
        allocation[i] = -1;

    // --- 3. First Fit Allocation Logic ---
    for (i = 0; i < np; i++) { // Iterate through all processes
        for (j = 0; j < nb; j++) { // Iterate through memory blocks
            // Check if the current block (b[j]) is large enough for the process (p[i])
            if (b[j] >= p[i]) {
                allocation[i] = j;      // Allocate process 'i' to block 'j'
                b[j] -= p[i];           // Reduce the available size of the block
                break;                  // Stop searching and move to the next process (FIRST FIT)
            }
        }
    }

    // --- 4. Display Allocation Results ---
    printf("\n--- First Fit Allocation Results ---\n");
    printf("Process No.\tProcess Size\tBlock No.\n");
    
    for (i = 0; i < np; i++) {
        if (allocation[i] != -1)
            // Block index is 'allocation[i]', so block number is 'allocation[i] + 1'
            printf("%d\t\t%d\t\t%d\n", i + 1, p[i], allocation[i] + 1);
        else
            printf("%d\t\t%d\t\tNot Allocated\n", i + 1, p[i]);
    }

    return 0;
}
